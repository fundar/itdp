-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 26-08-2012 a las 21:48:35
-- Versión del servidor: 5.5.9
-- Versión de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `itdp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta`
--

CREATE TABLE `encuesta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `correo` varchar(60) NOT NULL,
  `espacio_publico` float NOT NULL,
  `infraestructura_peatonal` float NOT NULL,
  `infraestructura_ciclista` float NOT NULL,
  `infraestructura_coche` float NOT NULL,
  `transporte_publico` float NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `edad` int(11) NOT NULL,
  `sexo` varchar(20) NOT NULL,
  `estado` varchar(30) NOT NULL,
  `zona_metropolitana` varchar(30) NOT NULL,
  `modo_transporte` varchar(30) NOT NULL,
  `gasto_promedio` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `encuesta`
--

INSERT INTO `encuesta` VALUES(1, 'pepe@pecas.com', 20, 33, 27, 13, 7, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(2, 'juan@juarez.com', 20, 33, 13, 27, 7, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(3, 'lui.morales@hihi.com', 7, 13, 20, 27, 33, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(4, 'berser.ar@gmail.com', 33, 27, 20, 13, 7, 'Antonio Sandoval Garcia', 23, 'Masculino', 'Distrito Federal', 'Mexico', 'Caminar', '10-20');
INSERT INTO `encuesta` VALUES(5, 'uis@aas.com', 13, 27, 33, 20, 7, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(6, 'asas.ar@gmail.com', 33, 27, 20, 13, 7, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(7, 'dsds.ar@gmail.com', 27, 33, 13, 7, 20, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(8, 'ber.wew@sddd.cm', 33, 27, 20, 7, 13, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(9, 'djsij@sdsd.com', 33, 27, 20, 13, 7, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(10, 'djksdj@dsdk.cp', 27, 33, 20, 13, 7, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(11, 'skaks.s@sas.com', 33, 27, 20, 13, 7, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(13, 'jorge@gmail.com', 27, 20, 33, 7, 13, 'Jorge', 26, 'Masculino', 'Distrito Federal', 'Mexico', 'Bicicleta', '0-10');
INSERT INTO `encuesta` VALUES(14, 'addiel@addiel.com', 33, 27, 7, 20, 13, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(15, 'jhgj@cic.com', 27, 20, 33, 7, 13, '', 0, '', '', '', '', '');
INSERT INTO `encuesta` VALUES(16, 'antono.sando@hot.com', 33, 27, 20, 13, 7, '', 0, '', '', '', '', '');
